"use strict";
Object . values ( [ 0 ] ) ; 
