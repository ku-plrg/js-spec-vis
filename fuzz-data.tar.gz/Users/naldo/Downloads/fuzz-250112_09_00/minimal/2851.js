"use strict";
Array . prototype . copyWithin . call ( { length : null } ) ; 
