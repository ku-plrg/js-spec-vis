"use strict";
import ( { [ Symbol . toPrimitive ] : function * ( ) { } } ) ; 
