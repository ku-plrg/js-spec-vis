"use strict";
let x ; [ 0n . x = 0 ] = `` ; 
