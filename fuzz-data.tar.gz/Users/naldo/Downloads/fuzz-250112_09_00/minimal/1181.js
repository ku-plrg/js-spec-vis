"use strict";
Promise . all . call ( function ( ) { } ) ; 
