"use strict";
var [ [ ] = `` [ 0 ] ] = '' ; 
