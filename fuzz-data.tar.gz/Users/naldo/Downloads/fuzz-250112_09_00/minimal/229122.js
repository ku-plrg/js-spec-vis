"use strict";
for ( { } . x ; ; ) x ; 
