"use strict";
'' . substring ( `` ) ; 
