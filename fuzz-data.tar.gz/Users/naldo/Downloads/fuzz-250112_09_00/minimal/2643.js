"use strict";
Array . prototype . fill ( 0 , { [ Symbol . toPrimitive ] : x => null } ) ; 
