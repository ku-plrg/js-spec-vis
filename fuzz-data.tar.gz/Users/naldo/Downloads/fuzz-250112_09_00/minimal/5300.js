"use strict";
for ( x of '' [ 0 ] ) ; 
