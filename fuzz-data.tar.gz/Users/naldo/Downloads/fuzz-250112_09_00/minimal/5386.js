"use strict";
var { ... x } = { get 0 ( ) { x ( ) ; } } ; 
