"use strict";
new 0 ( 0 , null . x ) ; 
