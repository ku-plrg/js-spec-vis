"use strict";
Array . prototype . map . call ( { length : `` } ) ; 
