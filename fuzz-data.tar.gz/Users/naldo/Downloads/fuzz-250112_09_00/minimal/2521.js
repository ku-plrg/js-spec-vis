"use strict";
+ '' [ 0 ] ; 
