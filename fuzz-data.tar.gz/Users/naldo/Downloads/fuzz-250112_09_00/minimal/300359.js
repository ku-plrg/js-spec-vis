"use strict";
Reflect . set ( { } , 1n ) ; 
