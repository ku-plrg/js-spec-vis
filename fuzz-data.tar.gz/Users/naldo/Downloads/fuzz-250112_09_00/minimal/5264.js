"use strict";
null ?? x ; 
