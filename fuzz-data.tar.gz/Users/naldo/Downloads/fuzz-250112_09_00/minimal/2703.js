"use strict";
Array . prototype . forEach . call ( `${ 0 }` , x => 0 ) ; 
