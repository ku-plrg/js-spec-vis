"use strict";
String . prototype . slice . call ( { [ Symbol . toPrimitive ] : x => 0 } ) ; 
