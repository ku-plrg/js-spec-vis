"use strict";
switch ( 0 ) { case x : function x ( ) { } default : } 
