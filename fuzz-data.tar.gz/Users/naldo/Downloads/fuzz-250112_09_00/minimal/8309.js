"use strict";
for ( 0 ; null . x ; ) ; 
