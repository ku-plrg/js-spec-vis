"use strict";
1 . toString ( { [ Symbol . toPrimitive ] : x => 1n } ) ; 
