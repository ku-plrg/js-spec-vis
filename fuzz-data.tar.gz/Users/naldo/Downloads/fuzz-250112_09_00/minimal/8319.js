"use strict";
0 ?. x [ ! 1 ] ; 
