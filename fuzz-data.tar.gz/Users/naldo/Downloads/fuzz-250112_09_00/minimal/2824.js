"use strict";
function x ( ) { } [ { 0 : x = x } = 0 ] = '' ; 
