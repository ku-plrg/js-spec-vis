"use strict";
async function x ( x = 0 ) { function x ( ) { } } x ( ) ; 
