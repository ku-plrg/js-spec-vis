"use strict";
var x = 0 instanceof `` [ 0 % 0 ] ; 
