"use strict";
[ ] . findLast . call ( x => x , x => `` ) ; 
