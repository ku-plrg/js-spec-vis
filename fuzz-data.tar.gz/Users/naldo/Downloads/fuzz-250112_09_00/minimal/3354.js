"use strict";
async function x ( ) { } 
