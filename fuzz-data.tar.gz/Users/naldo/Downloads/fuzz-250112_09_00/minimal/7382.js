"use strict";
~ `` [ 0 ] ; 
