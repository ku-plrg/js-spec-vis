"use strict";
-- { set 0 ( x ) { } } [ 0 ] ; 
