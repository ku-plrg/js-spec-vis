"use strict";
Array . prototype . push . call ( { length : { [ Symbol . toPrimitive ] : x => null } } ) ; 
