"use strict";
Array . prototype . copyWithin . call ( true ) ; 
