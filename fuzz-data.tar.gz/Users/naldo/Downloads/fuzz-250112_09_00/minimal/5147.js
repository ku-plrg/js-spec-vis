"use strict";
Array . prototype . filter . call ( { length : { [ Symbol . toPrimitive ] : x => await } } ) ; 
