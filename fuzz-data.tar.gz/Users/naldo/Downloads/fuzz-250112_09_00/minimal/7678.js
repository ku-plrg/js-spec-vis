"use strict";
null ? 0 : 0 ; 
