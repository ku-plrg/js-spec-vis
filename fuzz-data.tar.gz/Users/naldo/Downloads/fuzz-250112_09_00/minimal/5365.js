"use strict";
String . prototype . split ( 0 , { [ Symbol . toPrimitive ] : 0 } ) ; 
