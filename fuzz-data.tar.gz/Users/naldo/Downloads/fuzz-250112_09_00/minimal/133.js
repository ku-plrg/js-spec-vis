"use strict";
for ( ; x ; ) ; let x ; 
