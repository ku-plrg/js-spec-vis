"use strict";
let x ; [ , x , ] = '' ; 
