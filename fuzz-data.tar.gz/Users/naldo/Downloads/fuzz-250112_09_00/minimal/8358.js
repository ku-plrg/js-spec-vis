"use strict";
Array . prototype . indexOf . call ( [ 0 ] , 0 , `` ) ; 
