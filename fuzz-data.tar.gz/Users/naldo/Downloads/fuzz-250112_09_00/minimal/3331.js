"use strict";
new AggregateError ( 0 , { [ Symbol . toPrimitive ] : class { } } ) ; 
