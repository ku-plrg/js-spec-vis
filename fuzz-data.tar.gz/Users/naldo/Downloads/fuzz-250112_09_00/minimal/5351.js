"use strict";
Array . prototype . find . call ( 0 ) ; 
