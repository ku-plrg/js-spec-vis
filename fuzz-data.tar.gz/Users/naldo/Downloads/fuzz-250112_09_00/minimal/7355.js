"use strict";
; x = { [ Symbol . toPrimitive ] : class { } } - 0 ; 
