"use strict";
Object . create ( { } , { x : { writable : 0n } } ) ; 
