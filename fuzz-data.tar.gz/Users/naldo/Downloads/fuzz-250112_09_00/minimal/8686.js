"use strict";
let [ ] = [ ] ; 
