"use strict";
delete true . x ; 
