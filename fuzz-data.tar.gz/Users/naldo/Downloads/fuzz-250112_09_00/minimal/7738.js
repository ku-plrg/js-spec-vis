"use strict";
new Map ( [ { } ] ) ; 
