"use strict";
'' . concat . call ( ) ; 
