"use strict";
Promise . race . call ( ) ; 
