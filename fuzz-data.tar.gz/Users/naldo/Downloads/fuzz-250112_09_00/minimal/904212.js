"use strict";
[ ] . join . call ( `` ) ; 
