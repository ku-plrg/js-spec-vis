"use strict";
`${ 0 }${ { [ Symbol . toPrimitive ] : x => 0n } }` ; 
