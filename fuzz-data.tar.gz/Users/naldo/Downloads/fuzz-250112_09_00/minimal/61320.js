"use strict";
0 . __defineGetter__ ( ) ; 
