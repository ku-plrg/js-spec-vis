"use strict";
null ?? true . x ; 
