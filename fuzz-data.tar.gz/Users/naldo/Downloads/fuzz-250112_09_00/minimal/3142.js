"use strict";
BigInt . asUintN ( 0 , { [ Symbol . toPrimitive ] : 0 } ) ; 
