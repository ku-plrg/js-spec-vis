"use strict";
Object . getOwnPropertyNames ( true ) ; 
