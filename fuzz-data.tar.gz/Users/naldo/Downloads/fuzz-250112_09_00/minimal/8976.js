"use strict";
class x { async #x ( ) { } } 
