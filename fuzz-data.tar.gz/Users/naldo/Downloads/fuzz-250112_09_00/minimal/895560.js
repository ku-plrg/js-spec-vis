"use strict";
String . prototype . lastIndexOf ( 0 , { [ Symbol . toPrimitive ] : x => await } ) ; 
