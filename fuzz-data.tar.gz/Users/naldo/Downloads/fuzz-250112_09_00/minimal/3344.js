"use strict";
for ( let x of x ) ; 
