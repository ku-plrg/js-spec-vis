"use strict";
String . prototype . startsWith ( { [ Symbol . match ] : [ ] } ) ; 
