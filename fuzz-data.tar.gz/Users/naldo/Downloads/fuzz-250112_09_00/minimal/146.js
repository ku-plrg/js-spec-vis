"use strict";
new 0 ( 0 , 0 . x . x ) ; 
