"use strict";
{ while ( x ) ; let x ; } 
