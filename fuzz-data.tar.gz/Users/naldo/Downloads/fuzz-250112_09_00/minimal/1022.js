"use strict";
new Map ( { [ Symbol . iterator ] : async function * ( ) { } } ) ; 
