"use strict";
Math . log2 ( 1 ) ; 
