"use strict";
String . prototype . split ( ) ; 
