"use strict";
x &= 0 ; let x ; 
