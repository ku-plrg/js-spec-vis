"use strict";
[ ] . toSpliced ( x => x ) ; 
