"use strict";
Array . prototype . at . call ( { length : { [ Symbol . toPrimitive ] : class { } } } ) ; 
