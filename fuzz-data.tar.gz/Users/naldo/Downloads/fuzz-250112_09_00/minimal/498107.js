"use strict";
Reflect . apply ( x => x , 0 , [ ] ) ; 
