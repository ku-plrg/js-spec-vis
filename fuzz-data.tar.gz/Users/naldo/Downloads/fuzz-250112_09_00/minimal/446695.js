"use strict";
[ , x ] = [ , , ] ; 
