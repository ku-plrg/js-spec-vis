"use strict";
let x ; [ { 0 : x = class x { } } = 0 ] = '' ; 
