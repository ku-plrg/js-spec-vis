"use strict";
Array . prototype . find . call ( { length : { [ Symbol . toPrimitive ] : x => 0 } } ) ; 
