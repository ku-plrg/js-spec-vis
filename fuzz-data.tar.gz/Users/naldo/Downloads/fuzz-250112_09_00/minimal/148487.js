"use strict";
class x { static #x = await . #x ; } 
