"use strict";
var x = { } ; ; x . __proto__ = x ; 
