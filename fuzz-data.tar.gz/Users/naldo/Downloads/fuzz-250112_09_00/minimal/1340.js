"use strict";
Array . prototype . copyWithin ( 0 , { [ Symbol . toPrimitive ] : x => { } } ) ; 
