"use strict";
let x ; for ( x of [ 0 ] ) ; 
