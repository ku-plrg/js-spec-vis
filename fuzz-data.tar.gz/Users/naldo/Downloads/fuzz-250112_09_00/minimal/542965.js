"use strict";
{ let x ; if ( x ) ; } 
