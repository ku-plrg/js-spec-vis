"use strict";
class x { static 0 = { x } . x ; } 
