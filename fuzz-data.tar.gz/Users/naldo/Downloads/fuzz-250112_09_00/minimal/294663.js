"use strict";
isFinite ( ) ; 
