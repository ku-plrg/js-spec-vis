"use strict";
let x ; while ( x ) ; 
