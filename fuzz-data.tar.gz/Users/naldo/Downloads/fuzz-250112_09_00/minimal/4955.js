"use strict";
for ( let x ; ; [ ] = x ) ; 
