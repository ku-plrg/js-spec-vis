"use strict";
this <= 0 ; 
