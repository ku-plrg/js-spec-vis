"use strict";
[ , x => x ] . slice ( ) ; 
