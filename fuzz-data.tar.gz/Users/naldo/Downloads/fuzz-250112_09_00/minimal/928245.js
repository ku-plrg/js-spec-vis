"use strict";
[ , ... x ] = { [ Symbol . iterator ] : [ ] } ; 
