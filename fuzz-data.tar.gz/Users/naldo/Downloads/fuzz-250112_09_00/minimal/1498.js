"use strict";
eval ( `${ 0 }` ) ; 
