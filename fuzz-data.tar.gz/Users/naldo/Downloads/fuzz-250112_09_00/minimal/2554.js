"use strict";
'' != { [ Symbol . toPrimitive ] : x => - x } ; 
