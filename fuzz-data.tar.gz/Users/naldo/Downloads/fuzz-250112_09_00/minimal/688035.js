"use strict";
[ , x => x ] . filter ( x => 0n ) ; 
