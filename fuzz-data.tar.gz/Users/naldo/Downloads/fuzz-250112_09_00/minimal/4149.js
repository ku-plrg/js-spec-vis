"use strict";
for ( x in { set 0 ( [ ] ) { } } [ 0 ] ??= 0 ) ; 
