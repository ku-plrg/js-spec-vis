"use strict";
switch ( 0 ) { default : case 1 : } 
