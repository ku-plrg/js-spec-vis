"use strict";
Promise . allSettled . call ( [ ] ) ; 
