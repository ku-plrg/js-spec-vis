"use strict";
Object . fromEntries ( [ [ true ] ] ) ; 
