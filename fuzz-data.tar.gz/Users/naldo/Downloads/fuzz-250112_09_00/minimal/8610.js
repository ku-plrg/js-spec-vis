"use strict";
0 instanceof { [ Symbol . hasInstance ] : x => 1n } ; 
