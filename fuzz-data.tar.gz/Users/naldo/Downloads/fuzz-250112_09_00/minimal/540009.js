"use strict";
async function x ( ) { ; for await ( var x of `` [ x -- ] ) ; } x ( ) ; 
