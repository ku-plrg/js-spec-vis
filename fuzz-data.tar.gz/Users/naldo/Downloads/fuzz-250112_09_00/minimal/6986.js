"use strict";
var { 0 : [ ] = '' . x } = 0 ; 
