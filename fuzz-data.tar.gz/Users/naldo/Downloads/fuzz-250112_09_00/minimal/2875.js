"use strict";
0 <= { [ Symbol . toPrimitive ] : x => await } ; 
