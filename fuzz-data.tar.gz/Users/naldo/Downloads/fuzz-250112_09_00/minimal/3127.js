"use strict";
[ , x ] ; var x ; 
