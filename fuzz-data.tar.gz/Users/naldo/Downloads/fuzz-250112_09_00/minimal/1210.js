"use strict";
String . prototype . indexOf ( { [ Symbol . toPrimitive ] : x => true } ) ; 
