"use strict";
Object . defineProperties ( 0 , 0 ) ; 
