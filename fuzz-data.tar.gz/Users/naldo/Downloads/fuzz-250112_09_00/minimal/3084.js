"use strict";
async function x ( ) { ; for await ( var x of async function * ( ) { yield ; } ?. ( ) ) ; } x ( ) ; 
