"use strict";
[ x => x , , ] . reverse ( ) ; 
