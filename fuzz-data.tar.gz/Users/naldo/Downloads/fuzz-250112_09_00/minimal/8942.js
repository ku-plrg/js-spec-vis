"use strict";
~ { [ Symbol . toPrimitive ] : x => 0 } ; 
