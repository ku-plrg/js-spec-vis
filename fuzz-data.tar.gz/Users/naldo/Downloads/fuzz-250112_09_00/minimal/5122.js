"use strict";
Array . prototype . splice . call ( { 0 : `` } , 0 , 0 , 0 ) ; 
