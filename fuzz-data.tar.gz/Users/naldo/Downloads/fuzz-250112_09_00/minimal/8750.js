"use strict";
-- [ { [ Symbol . toPrimitive ] : class { } } ] [ 0 ] ; 
