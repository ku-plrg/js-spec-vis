"use strict";
Object . defineProperties ( [ ] , { x : { value : `` } } ?? 0 ) ; 
