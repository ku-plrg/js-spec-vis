"use strict";
for ( let x of { [ Symbol . iterator ] : async function * ( ) { } } ) break ; 
