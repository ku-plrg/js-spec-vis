"use strict";
class x { static { for await ( var x of { [ Symbol . asyncIterator ] : function ( ) { } } ) ; } } 
