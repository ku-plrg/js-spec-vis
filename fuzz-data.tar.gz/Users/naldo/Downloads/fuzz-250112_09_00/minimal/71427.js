"use strict";
Array . prototype . with ( '' ) ; 
