"use strict";
for ( x ; 0 ; 0 ) var x ; 
