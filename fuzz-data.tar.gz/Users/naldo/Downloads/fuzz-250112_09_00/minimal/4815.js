"use strict";
Array . prototype . unshift . call ( { length : { [ Symbol . toPrimitive ] : x => { } } } ) ; 
