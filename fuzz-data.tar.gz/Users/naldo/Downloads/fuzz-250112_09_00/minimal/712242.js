"use strict";
let x ; [ , x , ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
