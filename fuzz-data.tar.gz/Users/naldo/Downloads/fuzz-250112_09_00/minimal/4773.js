"use strict";
Object . hasOwn ( 0 , { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
