"use strict";
for ( var { } of function * ( ) { x } ( ) ) ; 
