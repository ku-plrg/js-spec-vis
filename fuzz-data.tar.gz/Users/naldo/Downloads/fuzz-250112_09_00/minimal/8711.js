"use strict";
switch ( 0 ) { case 0 : x ; default : } 
