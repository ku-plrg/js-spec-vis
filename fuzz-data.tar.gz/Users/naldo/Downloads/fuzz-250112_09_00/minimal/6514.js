"use strict";
for ( { } . x in [ 0 ] ) ; 
