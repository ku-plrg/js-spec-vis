"use strict";
let x = async x => await 0 . x ; x ( ) ; 
