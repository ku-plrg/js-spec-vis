"use strict";
Array . from . call ( 0 , `` ) ; 
