"use strict";
new function ( x , await ) { } ; 
