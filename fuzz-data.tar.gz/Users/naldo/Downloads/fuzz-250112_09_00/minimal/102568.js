"use strict";
Math . asinh ( '' ) ; 
