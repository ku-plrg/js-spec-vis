"use strict";
Math . sinh ( 1 ) ; 
