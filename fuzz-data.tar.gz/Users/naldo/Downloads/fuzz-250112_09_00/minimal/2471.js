"use strict";
Array . prototype . reverse . call ( { length : { [ Symbol . toPrimitive ] : x => await } } ) ; 
