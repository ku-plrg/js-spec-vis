"use strict";
x ?. x ; 
