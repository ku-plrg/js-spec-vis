"use strict";
do ; while ( 0 . x ) ; 
