"use strict";
Array . prototype . slice . call ( `` ) ; 
