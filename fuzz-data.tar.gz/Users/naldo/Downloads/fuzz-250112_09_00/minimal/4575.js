"use strict";
for ( let x in 0 . x ) ; 
