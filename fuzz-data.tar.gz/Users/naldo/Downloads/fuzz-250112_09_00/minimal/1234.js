"use strict";
class x { #x ; } new x ( ) ; 
