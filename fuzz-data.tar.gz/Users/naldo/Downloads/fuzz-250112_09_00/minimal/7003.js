"use strict";
; [ 0n ] [ 0 ] >>>= 1n ; 
