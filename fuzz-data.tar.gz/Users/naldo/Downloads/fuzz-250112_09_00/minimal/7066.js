"use strict";
- { [ Symbol . match ] : async function ( ) { } } ; 
