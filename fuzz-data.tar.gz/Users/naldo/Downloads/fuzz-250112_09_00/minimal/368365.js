"use strict";
class x { static #x = #x in { [ Symbol . toPrimitive ] : x => [ ] } >> 1 ; } 
