"use strict";
Promise . all ( { [ Symbol . iterator ] : 0 } ) ; 
