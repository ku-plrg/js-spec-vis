"use strict";
[ ] . x != 0 ; 
