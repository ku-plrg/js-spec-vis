"use strict";
x = { x } = 1n ; 
