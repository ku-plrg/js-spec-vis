"use strict";
new true . x ( ) ; 
