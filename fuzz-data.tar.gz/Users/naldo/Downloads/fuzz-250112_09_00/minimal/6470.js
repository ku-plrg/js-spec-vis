"use strict";
Object . create ( 0 , 1 ) ; 
