"use strict";
! async function * ( ) { } ; 
