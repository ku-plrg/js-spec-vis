"use strict";
Math . expm1 ( null ) ; 
