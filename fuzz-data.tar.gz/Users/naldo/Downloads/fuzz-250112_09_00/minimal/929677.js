"use strict";
Object . defineProperty ( [ ] , 42 , { writable : 0 } ) ; 
