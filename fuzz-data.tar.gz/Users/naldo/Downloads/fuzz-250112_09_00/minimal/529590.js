"use strict";
let x ; [ ... function * ( ) { ; yield x ; } `` ] ; 
