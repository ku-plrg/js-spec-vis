"use strict";
x ? 0 : x ; 
