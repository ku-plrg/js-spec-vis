"use strict";
var [ [ ] = `${ 0 }` [ 0 ] ] = '' ; 
