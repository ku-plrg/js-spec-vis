"use strict";
String . raw ( { raw : { length : 0n } } ) ; 
