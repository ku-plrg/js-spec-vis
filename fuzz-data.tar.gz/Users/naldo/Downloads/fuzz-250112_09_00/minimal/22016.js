"use strict";
String . prototype . trim . call ( [ ] ) ; 
