"use strict";
true . x ? 0 : 0 ; 
