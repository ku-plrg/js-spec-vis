"use strict";
String . prototype . endsWith ( 0 , { [ Symbol . toPrimitive ] : x => 0n } ) ; 
