"use strict";
String . prototype . padStart ( { [ Symbol . toPrimitive ] : function ( ) { } } ) ; 
