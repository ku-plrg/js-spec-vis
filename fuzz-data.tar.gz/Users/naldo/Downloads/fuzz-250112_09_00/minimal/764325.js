"use strict";
String . prototype . charCodeAt . call ( { [ Symbol . toPrimitive ] : x => false } ) ; 
