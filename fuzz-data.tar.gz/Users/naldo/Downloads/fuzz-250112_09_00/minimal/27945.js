"use strict";
String . prototype . concat ( ) ; 
