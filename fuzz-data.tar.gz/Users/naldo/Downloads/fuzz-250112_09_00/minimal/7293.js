"use strict";
Array . prototype . unshift . call ( [ 0 ] , 0 ) ; 
