"use strict";
for ( `` . x ; 0 ; ) ; 
