"use strict";
String . prototype . substring ( 0 , 0n ) ; 
