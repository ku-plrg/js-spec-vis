"use strict";
0 instanceof { [ Symbol . hasInstance ] : x => { } } ; 
