"use strict";
Array . prototype . lastIndexOf . call ( { length : { [ Symbol . toPrimitive ] : x => 0 } } ) ; 
