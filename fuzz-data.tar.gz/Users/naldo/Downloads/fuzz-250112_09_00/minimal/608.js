"use strict";
Object . getPrototypeOf ( 0 ) ; 
