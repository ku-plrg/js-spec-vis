"use strict";
class x { static #x ; } 
