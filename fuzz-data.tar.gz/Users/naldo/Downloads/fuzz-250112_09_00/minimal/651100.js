"use strict";
{ let x ; x *= x ; } 
