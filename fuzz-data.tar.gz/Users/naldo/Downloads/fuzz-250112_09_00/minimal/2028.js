"use strict";
async function * x ( ... x ) { } x ( 0 ) ; 
