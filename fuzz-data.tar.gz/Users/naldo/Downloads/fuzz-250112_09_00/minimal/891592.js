"use strict";
`` . slice ( 0 , { } ) ; 
