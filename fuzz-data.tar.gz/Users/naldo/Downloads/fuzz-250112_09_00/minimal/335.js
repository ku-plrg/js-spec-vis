"use strict";
for ( var x of function * ( ) { yield ; } ( ) ) throw 0 ; 
