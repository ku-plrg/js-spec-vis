"use strict";
Array . prototype . fill ( 0 , 0 , { [ Symbol . toPrimitive ] : 0 } ) ; 
