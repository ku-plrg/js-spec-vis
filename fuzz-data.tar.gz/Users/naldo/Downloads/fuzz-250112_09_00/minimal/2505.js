"use strict";
for ( x in [ 0 ] ) ; let x ; 
