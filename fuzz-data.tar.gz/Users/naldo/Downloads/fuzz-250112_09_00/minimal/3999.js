"use strict";
[ { [ Symbol . toPrimitive ] : x => new 0 } ] [ 0 ] > 0 ; 
