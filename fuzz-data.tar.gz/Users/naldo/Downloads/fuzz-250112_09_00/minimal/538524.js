"use strict";
Math . acosh ( 1 ) ; 
