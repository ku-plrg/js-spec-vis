"use strict";
let x = x => 0 ? 0 <= 0 : 0 ( ) . x ||= 0 ; x ( ) ; 
