"use strict";
[ ] . unshift ( `` , 0 ) ; 
