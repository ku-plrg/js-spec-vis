"use strict";
Array . prototype . findIndex . call ( null ) ; 
