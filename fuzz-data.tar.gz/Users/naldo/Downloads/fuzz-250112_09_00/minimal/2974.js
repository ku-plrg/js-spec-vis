"use strict";
Array . prototype . findIndex . call ( x => 0 , x => x ) ; 
