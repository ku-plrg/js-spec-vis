"use strict";
String . prototype . startsWith . call ( { [ Symbol . toPrimitive ] : x => 1n } ) ; 
