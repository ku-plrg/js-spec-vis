"use strict";
Array . prototype . slice . call ( { length : { [ Symbol . toPrimitive ] : x => true } } ) ; 
