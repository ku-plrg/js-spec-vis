"use strict";
Object . getOwnPropertyDescriptor ( 1n ) ; 
