"use strict";
Object . getOwnPropertyNames ( 1n ) ; 
