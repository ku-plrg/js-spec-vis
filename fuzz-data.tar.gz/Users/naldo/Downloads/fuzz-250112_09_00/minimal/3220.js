"use strict";
0 + { get 0 ( ) { } , } [ 0 ] ; 
