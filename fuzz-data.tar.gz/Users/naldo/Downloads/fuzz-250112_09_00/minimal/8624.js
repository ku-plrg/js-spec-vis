"use strict";
String . prototype . indexOf ( { [ Symbol . toPrimitive ] : class { } } ) ; 
