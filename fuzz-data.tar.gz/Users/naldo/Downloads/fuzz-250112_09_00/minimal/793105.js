"use strict";
'' . replaceAll ( { [ Symbol . match ] : null } ) ; 
