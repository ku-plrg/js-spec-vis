"use strict";
'' ?. [ 0 ] === x ; 
