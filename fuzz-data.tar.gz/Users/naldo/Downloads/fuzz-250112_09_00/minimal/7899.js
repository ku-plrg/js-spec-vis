"use strict";
~ 0n . x ; 
