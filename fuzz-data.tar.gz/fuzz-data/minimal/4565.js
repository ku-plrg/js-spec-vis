"use strict";
BigInt . asIntN ( { [ Symbol . toPrimitive ] : x => null } ) ; 
