"use strict";
[ , ] = { [ Symbol . iterator ] : async function * ( ) { yield [ ] ; } } ; 
