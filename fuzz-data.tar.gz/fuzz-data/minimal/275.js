"use strict";
Array . prototype . reduce . call ( { length : null } ) ; 
