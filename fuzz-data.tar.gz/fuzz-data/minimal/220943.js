"use strict";
Array . prototype . includes . call ( { length : { [ Symbol . toPrimitive ] : x => 1n } } ) ; 
