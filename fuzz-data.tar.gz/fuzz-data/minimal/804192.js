"use strict";
Function ( { } , '' ) ; 
