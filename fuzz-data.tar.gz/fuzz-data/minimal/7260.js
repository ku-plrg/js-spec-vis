"use strict";
var [ x = 0 . x ] = '' ; 
