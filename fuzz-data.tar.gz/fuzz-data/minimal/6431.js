"use strict";
1n <= 0n ; 
