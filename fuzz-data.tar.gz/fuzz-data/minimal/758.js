"use strict";
for ( const x = 0 ; 0 ; ) ; 
