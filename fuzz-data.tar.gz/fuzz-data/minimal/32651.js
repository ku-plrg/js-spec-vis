"use strict";
String . prototype . replaceAll ( ) ; 
