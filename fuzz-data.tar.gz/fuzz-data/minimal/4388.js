"use strict";
`${ `` [ 0 ] }` ; 
