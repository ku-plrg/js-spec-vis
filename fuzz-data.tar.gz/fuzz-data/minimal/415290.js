"use strict";
[ ] . at ( true ) ; 
