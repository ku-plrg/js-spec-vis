"use strict";
0 >= true . x ; 
