"use strict";
Reflect . construct ( function ( ) { x ; } , x => x ) ; 
