"use strict";
'' . substring ( 1n ) ; 
