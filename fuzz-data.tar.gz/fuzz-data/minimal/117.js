"use strict";
0 . x |= { [ Symbol . toPrimitive ] : x => [ ] } ; 
