"use strict";
for ( var x in null . x ) ; 
