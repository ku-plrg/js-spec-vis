"use strict";
Function . call . call ( [ ] ) ; 
