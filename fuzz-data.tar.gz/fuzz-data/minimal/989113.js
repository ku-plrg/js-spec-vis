"use strict";
Array . prototype . reduce . call ( `${ 42 }` , x => 0 ) ; 
