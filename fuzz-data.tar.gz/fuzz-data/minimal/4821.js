"use strict";
Array . prototype . splice ( { [ Symbol . toPrimitive ] : class { } } ) ; 
