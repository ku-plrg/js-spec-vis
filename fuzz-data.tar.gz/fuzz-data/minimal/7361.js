"use strict";
var [ x = await ] = '' ; 
