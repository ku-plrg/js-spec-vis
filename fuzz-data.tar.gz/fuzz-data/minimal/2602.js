"use strict";
Array . prototype . indexOf . call ( { length : { } } ) ; 
