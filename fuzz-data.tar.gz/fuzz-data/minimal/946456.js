"use strict";
; [ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ] in { } ; 
