"use strict";
0 . __defineGetter__ ( { [ Symbol . toPrimitive ] : 0 } , x => 0 ) ; 
