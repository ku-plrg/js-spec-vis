"use strict";
Array . from ( { [ Symbol . iterator ] : 0 } ) ; 
