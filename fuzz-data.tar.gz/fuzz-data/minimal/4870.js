"use strict";
Promise . all ( [ { then : x => { } } ] ) ; 
