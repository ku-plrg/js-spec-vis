"use strict";
Array . prototype . splice . call ( [ 0 , , ] , 1 ) ; 
