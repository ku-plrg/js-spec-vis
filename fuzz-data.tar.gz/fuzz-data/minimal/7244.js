"use strict";
switch ( { get 0 ( ) { return ; } } [ 0 ] -- ) { default : ; } 
