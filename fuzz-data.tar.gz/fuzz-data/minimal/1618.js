"use strict";
BigInt ( 0 ) ; 
