"use strict";
class x extends 0 . x . x { } 
