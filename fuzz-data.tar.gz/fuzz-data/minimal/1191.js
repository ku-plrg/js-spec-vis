"use strict";
async function x ( ) { ; for await ( [ ] of [ 0 ] ) ; } x ( ) ; 
