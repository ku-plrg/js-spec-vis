"use strict";
0 ( 0 , ... `` ) ; 
