"use strict";
String . prototype . slice . call ( { [ Symbol . toPrimitive ] : x => true } ) ; 
