"use strict";
[ ... function * ( ) { yield x -- ; } `` ] ; 
