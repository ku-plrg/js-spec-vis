"use strict";
0n . x >= 1 ; 
