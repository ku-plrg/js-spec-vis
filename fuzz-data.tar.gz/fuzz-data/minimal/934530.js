"use strict";
[ ] . reduce . call ( null ) ; 
