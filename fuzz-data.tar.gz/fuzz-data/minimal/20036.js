"use strict";
- { set [ x ] ( x ) { } } ; 
