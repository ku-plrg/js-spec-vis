"use strict";
( x => 0 ? async function ( ) { } : 0 ( ) . x = 0 ) ( ) ; 
