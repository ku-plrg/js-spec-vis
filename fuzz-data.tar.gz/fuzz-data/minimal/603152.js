"use strict";
Math . atanh ( 1 ) ; 
