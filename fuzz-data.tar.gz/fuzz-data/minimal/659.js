"use strict";
this . toString . call ( 1n ) ; 
