"use strict";
let x ; [ x = class extends 0 { } ] = `` ; 
