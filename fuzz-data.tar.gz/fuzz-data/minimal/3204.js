"use strict";
Symbol ( { [ Symbol . toPrimitive ] : x => true } ) ; 
