"use strict";
class x { static { for await ( let [ ] of x ) ; } } 
