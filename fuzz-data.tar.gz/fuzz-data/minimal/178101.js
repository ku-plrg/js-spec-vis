"use strict";
new AggregateError ( { [ Symbol . iterator ] : function * ( ) { x } } ) ; 
