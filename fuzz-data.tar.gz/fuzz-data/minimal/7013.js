"use strict";
typeof class { } ; 
