"use strict";
[ , x => x ] . flatMap ( x => x `` ) ; 
