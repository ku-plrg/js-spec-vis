"use strict";
[ ] == 1n ; 
