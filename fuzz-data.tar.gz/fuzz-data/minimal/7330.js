"use strict";
true . x -- ; 
