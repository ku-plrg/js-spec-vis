"use strict";
Array . prototype . push . call ( 1n ) ; 
