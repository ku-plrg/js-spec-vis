"use strict";
class x { static { for await ( let x of { [ Symbol . iterator ] : 0 } ) ; } } 
