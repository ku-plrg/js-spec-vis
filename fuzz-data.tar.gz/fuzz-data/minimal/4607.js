"use strict";
class x { static #x = x &&= super . x ; } 
