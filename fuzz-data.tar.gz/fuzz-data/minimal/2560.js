"use strict";
let x = class extends 0 { } ; 
