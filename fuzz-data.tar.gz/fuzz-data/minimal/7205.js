"use strict";
'' >>> 0 ; 
