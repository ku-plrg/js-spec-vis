"use strict";
for ( 0 ; x ; 0 ) var x ; 
