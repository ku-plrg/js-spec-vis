"use strict";
let x ; throw x ; 
