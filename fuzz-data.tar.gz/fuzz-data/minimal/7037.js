"use strict";
x == x ; var x ; 
