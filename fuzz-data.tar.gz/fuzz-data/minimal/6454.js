"use strict";
0 instanceof '' . x ; 
