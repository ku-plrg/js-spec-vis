"use strict";
class x { static { for await ( var x of { [ Symbol . iterator ] : x => { } } ) ; } } 
