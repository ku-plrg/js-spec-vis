"use strict";
[ ] . shift . call ( { length : true } ) ; 
