"use strict";
String . prototype . startsWith ( { [ Symbol . toPrimitive ] : 0 } ) ; 
