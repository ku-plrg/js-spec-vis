"use strict";
Math . log10 ( '' ) ; 
