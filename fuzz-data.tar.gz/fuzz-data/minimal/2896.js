"use strict";
Object . getOwnPropertyDescriptor ( { } ) ; 
