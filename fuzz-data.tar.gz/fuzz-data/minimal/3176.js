"use strict";
String . prototype . charAt ( { [ Symbol . toPrimitive ] : x => true } ) ; 
