"use strict";
WeakSet . prototype . delete ( 0 ) ; 
