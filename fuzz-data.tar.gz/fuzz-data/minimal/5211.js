"use strict";
String . prototype . padEnd . call ( { [ Symbol . toPrimitive ] : x => false } ) ; 
