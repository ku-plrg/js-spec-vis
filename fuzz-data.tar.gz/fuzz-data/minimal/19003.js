"use strict";
WeakMap . prototype . delete ( ) ; 
