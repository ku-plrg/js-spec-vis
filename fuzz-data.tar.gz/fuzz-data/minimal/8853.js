"use strict";
String . prototype . substring ( 0 , { } ) ; 
