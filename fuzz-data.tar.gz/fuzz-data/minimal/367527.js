"use strict";
`` . indexOf ( true ) ; 
