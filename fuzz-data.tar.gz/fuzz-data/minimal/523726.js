"use strict";
'' . includes . call ( 0n ) ; 
