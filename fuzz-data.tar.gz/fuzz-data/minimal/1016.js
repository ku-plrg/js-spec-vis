"use strict";
var { x = x != { [ Symbol . toPrimitive ] : { } } + x } = 0 ; 
