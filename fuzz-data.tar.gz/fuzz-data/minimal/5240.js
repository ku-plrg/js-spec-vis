"use strict";
class x extends class { } { ; } new x ( ) ; 
