"use strict";
try { } catch { } 
