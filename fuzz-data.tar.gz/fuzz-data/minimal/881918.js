"use strict";
Math . ceil ( null ) ; 
