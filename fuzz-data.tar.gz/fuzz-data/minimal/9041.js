"use strict";
0 % 1 ; 
