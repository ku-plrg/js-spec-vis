"use strict";
Function . call . call ( 0 ) ; 
