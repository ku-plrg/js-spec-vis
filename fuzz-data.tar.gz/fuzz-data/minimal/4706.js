"use strict";
switch ( 0 ) { case 0 : default : break ; case 0 : } 
