"use strict";
Array . prototype . fill ( 0 , 0 , { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
