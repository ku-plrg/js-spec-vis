"use strict";
let x ; [ [ ] [ 0 ] = 0 ] = `` ; 
