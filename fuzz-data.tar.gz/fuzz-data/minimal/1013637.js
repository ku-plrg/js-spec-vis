"use strict";
class x { [ import ( x ) ] ; } 
