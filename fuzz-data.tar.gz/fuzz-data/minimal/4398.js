"use strict";
var x = null . x ; 
