"use strict";
let x ; [ { } = 0 ] = `` ; 
