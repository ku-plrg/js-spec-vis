"use strict";
Math . sign ( { [ Symbol . toPrimitive ] : x => x } ) ; 
