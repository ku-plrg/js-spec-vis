"use strict";
- { 0 : 0 , 0 ( ) { } } ; 
