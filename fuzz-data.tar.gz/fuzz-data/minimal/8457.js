"use strict";
eval . call ( 0 , `${ { } }` ) ; 
