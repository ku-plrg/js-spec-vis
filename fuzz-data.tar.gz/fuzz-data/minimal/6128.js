"use strict";
[ { [ Symbol . toPrimitive ] : 0 } ] != 0 ; 
