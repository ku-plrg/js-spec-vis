"use strict";
var [ , [ ] ] = '' ; 
