"use strict";
1n != { [ Symbol . toPrimitive ] : x => - x } ; 
