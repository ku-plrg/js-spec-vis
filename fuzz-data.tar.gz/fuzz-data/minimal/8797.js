"use strict";
for ( var x of [ 0 ] ) 0 ; 
