"use strict";
Math . expm1 ( 1n ) ; 
