"use strict";
'' . lastIndexOf . call ( [ ] ) ; 
