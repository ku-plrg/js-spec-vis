"use strict";
'' . replaceAll ( { [ Symbol . match ] : 0n } ) ; 
