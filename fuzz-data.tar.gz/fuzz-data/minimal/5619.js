"use strict";
Array . prototype . map . call ( { length : { [ Symbol . toPrimitive ] : [ ] } } ) ; 
