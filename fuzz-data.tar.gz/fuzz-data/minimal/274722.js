"use strict";
class x { static { for await ( let x of new . target ) ; } } 
