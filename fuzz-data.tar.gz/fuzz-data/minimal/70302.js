"use strict";
Math . min ( ) ; 
