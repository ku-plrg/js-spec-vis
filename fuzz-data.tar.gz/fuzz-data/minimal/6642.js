"use strict";
0 . x . x / 0 ; 
