"use strict";
[ , x => x ] . concat ( ) ; 
