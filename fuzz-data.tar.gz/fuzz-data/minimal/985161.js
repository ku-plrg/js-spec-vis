"use strict";
[ , x => x , , , ] . unshift ( 0 ) ; 
