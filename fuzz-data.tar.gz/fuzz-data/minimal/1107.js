"use strict";
'str' [ 0 ] ++ ; 
