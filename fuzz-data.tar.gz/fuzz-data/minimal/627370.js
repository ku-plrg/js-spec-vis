"use strict";
[ ] . lastIndexOf . call ( x => x ) ; 
