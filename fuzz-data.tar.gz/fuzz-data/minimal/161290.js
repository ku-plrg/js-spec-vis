"use strict";
Math . log2 ( 0 ) ; 
