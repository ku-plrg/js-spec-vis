"use strict";
Array . prototype . splice . call ( { length : null } ) ; 
