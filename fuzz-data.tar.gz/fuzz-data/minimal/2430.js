"use strict";
Array . prototype . slice ( { [ Symbol . toPrimitive ] : x => { } } ) ; 
