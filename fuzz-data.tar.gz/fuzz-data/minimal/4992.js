"use strict";
0 . __lookupSetter__ ( { [ Symbol . toPrimitive ] : class { } } ) ; 
