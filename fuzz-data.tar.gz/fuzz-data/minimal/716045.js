"use strict";
[ ... function * ( ) { return 0 ; } `` ] ; 
