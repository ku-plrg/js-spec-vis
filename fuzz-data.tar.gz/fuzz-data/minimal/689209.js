"use strict";
Object . defineProperty ( [ ] , `` , { writable : null } ) ; 
