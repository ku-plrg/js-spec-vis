"use strict";
0n * 0n ; 
