"use strict";
0 . __defineGetter__ . call ( 0 [ 0 ] &&= 0 ) ; 
