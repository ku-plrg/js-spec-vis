"use strict";
[ , ] = { [ Symbol . iterator ] : async function * ( ) { yield * '' [ 0 % 0 ] ; } } ; 
