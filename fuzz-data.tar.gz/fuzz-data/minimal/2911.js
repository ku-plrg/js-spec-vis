"use strict";
String . prototype . concat . call ( { [ Symbol . toPrimitive ] : x => await } ) ; 
