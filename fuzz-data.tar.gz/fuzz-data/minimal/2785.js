"use strict";
0 == { [ Symbol . toPrimitive ] : class { } } ; 
