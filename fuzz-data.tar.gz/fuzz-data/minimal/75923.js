"use strict";
Math . atan2 ( 0 , 0n ) ; 
