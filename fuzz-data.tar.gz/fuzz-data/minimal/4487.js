"use strict";
class x { } x !== { } ; 
