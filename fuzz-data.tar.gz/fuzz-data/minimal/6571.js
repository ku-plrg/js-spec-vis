"use strict";
- { [ Symbol . match ] : x => 0 } ; 
