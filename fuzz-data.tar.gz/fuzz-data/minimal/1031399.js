"use strict";
[ ] . slice ( 1 ) ; 
