"use strict";
Reflect . set ( 0 ) ; 
