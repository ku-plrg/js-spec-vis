"use strict";
Math . acosh ( { [ Symbol . toPrimitive ] : x => [ ] } ) ; 
