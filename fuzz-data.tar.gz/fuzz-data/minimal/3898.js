"use strict";
Array . prototype . splice ( 0 , { [ Symbol . toPrimitive ] : class { } } ) ; 
