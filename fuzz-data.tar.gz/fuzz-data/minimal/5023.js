"use strict";
[ ] . x == x ; 
