"use strict";
[ , x => x ] . findLast ( ) ; 
