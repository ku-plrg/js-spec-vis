"use strict";
Reflect . apply ( x => { } , 0 , [ ] ) ; 
