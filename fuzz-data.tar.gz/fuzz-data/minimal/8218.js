"use strict";
let x = x => 0 ?. ( ) ; x ( ) ; 
