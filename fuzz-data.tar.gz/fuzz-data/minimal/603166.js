"use strict";
Math . atanh ( `` ) ; 
