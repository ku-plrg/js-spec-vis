"use strict";
new Map ( [ [ 0 , 0 ] ] ) ; 
