"use strict";
Math . pow ( 0 ) ; 
