"use strict";
[ ] . splice . call ( true ) ; 
