"use strict";
class x { static #x = #x in super . x % 0 ; } 
