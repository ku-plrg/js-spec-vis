"use strict";
switch ( 0n ) { case 0n : } 
