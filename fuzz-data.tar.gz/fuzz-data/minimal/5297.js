"use strict";
[ [ ] ] [ 0 ] ++ ; 
