"use strict";
0 . hasOwnProperty ( true ) ; 
