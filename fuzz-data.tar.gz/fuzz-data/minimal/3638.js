"use strict";
for ( var [ ] = 0 ; ; ) ; 
