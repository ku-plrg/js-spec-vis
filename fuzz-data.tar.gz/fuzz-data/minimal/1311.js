"use strict";
async function x ( ) { ; for await ( x of 0 ?. ( ) ) ; } x ( ) ; 
