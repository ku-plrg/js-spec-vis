"use strict";
var [ x ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
