"use strict";
'' . replace . call ( 1 ) ; 
