"use strict";
[ ] . reduce . call ( ) ; 
