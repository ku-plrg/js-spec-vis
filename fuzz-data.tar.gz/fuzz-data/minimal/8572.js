"use strict";
Promise . prototype . catch . call ( 0n ) ; 
