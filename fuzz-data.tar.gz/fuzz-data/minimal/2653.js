"use strict";
Array . prototype . lastIndexOf . call ( [ 0 ] , 0 , { [ Symbol . toPrimitive ] : x => true } ) ; 
