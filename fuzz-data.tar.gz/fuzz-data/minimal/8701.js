"use strict";
String . prototype . slice . call ( true ) ; 
