"use strict";
0 [ null . x ] ; 
