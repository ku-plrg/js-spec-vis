"use strict";
0 [ true . x , 0 ] ; 
