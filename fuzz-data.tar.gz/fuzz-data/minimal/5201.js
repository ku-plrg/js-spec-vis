"use strict";
for ( ; true . x ; 0 ) ; 
