"use strict";
`${ { [ Symbol . toPrimitive ] : [ ] } }` ; 
