"use strict";
`${ 0 }` . propertyIsEnumerable ( 0 ) ; 
