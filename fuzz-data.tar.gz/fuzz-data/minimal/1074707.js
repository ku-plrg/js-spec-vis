"use strict";
[ , x , ] = { [ Symbol . iterator ] : x => { } } ; 
