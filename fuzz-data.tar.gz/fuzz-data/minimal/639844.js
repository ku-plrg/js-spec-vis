"use strict";
`` . indexOf ( 0 , null ) ; 
