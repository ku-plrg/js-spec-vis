"use strict";
Object . assign ( 0 , { get '' ( ) { return ; } , } ) ; 
