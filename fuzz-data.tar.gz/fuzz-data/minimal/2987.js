"use strict";
( async x => { for await ( let x of { [ Symbol . asyncIterator ] : function * ( ) { } } ) ; } ) ( ) ; 
