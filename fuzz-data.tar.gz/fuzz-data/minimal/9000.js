"use strict";
for ( x in x ) ; 
