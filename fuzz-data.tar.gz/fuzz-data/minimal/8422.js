"use strict";
Function ( [ ] ) ; 
