"use strict";
for ( var x of { [ Symbol . iterator ] : 0 } ) ; 
